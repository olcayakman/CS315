

for i in range(5):
    i = 4
    print(i+1)

print("__________")
print("")



i = "not in loop"
for i in "in-loop":
    i = 'p'
    print(i)
print(i)


print("__________")
print("")


myArr = [True, False, True, True]
for i in myArr:
    print(i)
